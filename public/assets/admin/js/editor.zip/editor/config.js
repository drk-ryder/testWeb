CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	config.uiColor = '#92d050';
	config.extraPlugins = 'autogrow';
	config.autoGrow_minHeight = 550;
	config.autoGrow_maxHeight = 600;
};
